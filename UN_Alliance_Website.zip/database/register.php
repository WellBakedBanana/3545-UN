<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "un_alliance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $screenshot = $_FILES['screenshot']['name'];

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($screenshot);
    move_uploaded_file($_FILES["screenshot"]["tmp_name"], $target_file);

    $sql = "INSERT INTO players (username, screenshot) VALUES ('$username', '$screenshot')";
    if ($conn->query($sql) === TRUE) {
        echo "Registrierung erfolgreich!";
    } else {
        echo "Fehler: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>